void stripPasswordResetFromBrowserUrl() {}
